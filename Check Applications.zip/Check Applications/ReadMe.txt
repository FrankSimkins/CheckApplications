Created by Frank Simkins 2018
_____________________________________________________________________________


How-to: Add a program:

Get the file location and add it to a new line in Programs.txt

_____________________________________________________________________________

How-to: Remove a program:

Delete the program from the list in Programs.txt

_____________________________________________________________________________

Troubleshooting: Blank modules

If you have blank modules showing up, delete any blank spaces in the Programs.txt file.

_____________________________________________________________________________

Source Code:

https://github.com/FrankSimkins/CheckApplications